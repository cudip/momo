﻿namespace momos.Views.Home
{
    public class Contact
    {
    }
}
